// controllers/admin.controller.js

const adminService = require("../services/admin.service");
const { success, error, notFound } = require("../utils/response");

exports.getStats = async (req, reply) => {
  try {
    return success(reply, await adminService.getStats());
  } catch (err) {
    return error(reply, err.message);
  }
};

exports.getAllUsers = async (req, reply) => {
  try {
    return success(reply, await adminService.getAllUsers());
  } catch (err) {
    return error(reply, err.message);
  }
};

exports.getUserById = async (req, reply) => {
  try {
    const user = await adminService.getUserById(req.params.id);
    if (!user) return notFound(reply, "User not found");
    return success(reply, user);
  } catch (err) {
    return error(reply, err.message);
  }
};

exports.createUser = async (req, reply) => {
  try {
    const user = await adminService.createUser(req.body);
    return success(reply, user, 201);
  } catch (err) {
    return error(reply, err.message, err.statusCode || 500);
  }
};

exports.updateUser = async (req, reply) => {
  try {
    const user = await adminService.updateUser(req.params.id, req.body);
    return success(reply, user);
  } catch (err) {
    return error(reply, err.message, err.statusCode || 500);
  }
};

exports.deleteUser = async (req, reply) => {
  try {
    const user = await adminService.deleteUser(req.params.id);
    if (!user) return notFound(reply, "User not found");
    return success(reply, { message: "User deleted successfully" });
  } catch (err) {
    return error(reply, err.message);
  }
};